#ULM DEBATE 
#Description: It adds or chooses random debatae topics about ULM that doesn't require 
#public feedback to operate. 
#The problem with first-time,long-time,or anticipating students is how to disextinguish from right and wrong in the ULM space.
#some things don't equate to what they did in highs school, so they have to adapt but don't know people who they can adapt from.
#That's what this app is trying to do for, so they can stay in line for their future semesters here.
#the startup wasn't great, but once I understood everything, it was easy.
# GITHUB LINK: 
#Alandius McDonald

import random


topics = [
    "Should ULM offer more online courses?",
    "Should attendance be mandatory for college classes?",
    "Are online classes better than in-person classes?",
    "Should ULM offer more evening classes?",
    "Should professors give less homework?",
    "Should exams count less toward final grades?",
    "Should students be allowed to use AI for assignments?",
    "Should ULM offer more summer courses?",
    "Should group projects be required?",
    "Should college textbooks be free?",
    "Should students choose their own deadlines?",
    "Should participation count toward a student's grade?"
]


def add_topic():
    topic = input("\nEnter your debate topic: ").strip()

    if topic:
        topics.append(topic)
        print("Your topic was added successfully!")
    else:
        print("Topic cannot be empty.")


def view_topics():
    print("\n========== AVAILABLE DEBATE TOPICS ==========")

    for number, topic in enumerate(topics, start=1):
        print(f"{number}. {topic}")

    print("=============================================")

    choice = input(
        "\nChoose a topic number (or 0 to return): "
    ).strip()

    if not choice.isdigit():
        print("Please enter a valid number.")
        return

    number = int(choice)

    if number == 0:
        return

    if 1 <= number <= len(topics):
        debate(topics[number - 1])
    else:
        print("That topic number does not exist.")


def simulate_debate(topic, position, argument):
    print("\n" + "=" * 55)
    print("          THINK ABOUT IT: DEBATE SIMULATION")
    print("=" * 55)

    print("\nYour opinion:")
    print(position)
    print(argument)

    # Student perspectives
    student_agrees = [
        "I agree with your position because it could make "
        "college more convenient for students.",
        "I support your opinion because students need options "
        "that fit their schedules and responsibilities.",
        "I agree. This could help students manage their "
        "education and personal lives."
    ]

    student_disagrees = [
        "I disagree because this change might create "
        "new challenges for students.",
        "I see your point, but students have different needs, "
        "and this approach might not work for everyone.",
        "I disagree. We should consider the disadvantages "
        "before making this change."
    ]

    # Professor perspectives
    professor_agrees = [
        "I agree with your argument. We should consider "
        "whether this change could improve student learning.",
        "I support your position, provided that academic "
        "standards and course quality are maintained.",
        "Your argument makes sense. A change like this could "
        "be beneficial if it is planned carefully."
    ]

    professor_disagrees = [
        "I disagree because we must also consider course "
        "requirements, learning outcomes, and fairness.",
        "I understand your argument, but this change could "
        "create additional challenges for instructors.",
        "I see the benefits, but we should examine the "
        "possible effects before adopting this approach."
    ]

    # Randomly choose a student and professor response
    print("\n--- ULM STUDENT #1: AGREES WITH YOU ---")
    print(random.choice(student_agrees))
    print("Regarding the topic:", topic)

    print("\n--- ULM STUDENT #2: DISAGREES WITH YOU ---")
    print(random.choice(student_disagrees))
    print("Regarding the topic:", topic)

    print("\n--- ULM PROFESSOR #1: AGREES WITH YOU ---")
    print(random.choice(professor_agrees))
    print("Regarding the topic:", topic)

    print("\n--- ULM PROFESSOR #2: DISAGREES WITH YOU ---")
    print(random.choice(professor_disagrees))
    print("Regarding the topic:", topic)

    # Let the user respond after hearing both sides
    print("\n========== YOUR TURN TO RESPOND ==========")

    response = input(
        "Which argument do you agree with most, and why? "
    ).strip()

    print("\nYour response:")
    print(response if response else "No response entered.")

    reflection = input(
        "\nDid hearing both sides change your opinion? Why or why not? "
    ).strip()

    print("\n========== FINAL DEBATE SUMMARY ==========")
    print("Topic:", topic)
    print("Your original position:", position)
    print("Your original argument:", argument)
    print("Your response to the simulation:", response)
    print("Your final reflection:", reflection)
    print("\nRemember: Thinking critically means considering "
          "different perspectives before reaching a conclusion.")
    print("===========================================")


def debate(topic):
    print("\n" + "=" * 55)
    print("                 ULM COURSE DEBATE")
    print("=" * 55)

    print("\nSelected Topic:")
    print(topic)

    print("\nBefore seeing other opinions, think about your own.")

    print("\nChoose your position:")
    print("1. Agree")
    print("2. Disagree")
    print("3. Undecided")

    choice = input("Enter 1, 2, or 3: ").strip()

    if choice == "1":
        position = "Agree"
    elif choice == "2":
        position = "Disagree"
    elif choice == "3":
        position = "Undecided"
    else:
        print("Invalid choice. Please try again.")
        return

    # The user gives their opinion BEFORE the simulation
    argument = input(
        "\nExplain why you chose this position: "
    ).strip()

    if not argument:
        print("Please enter an argument before starting the simulation.")
        return

    print("\nThank you! Now let's see how other people might respond.")

    simulate_debate(topic, position, argument)


def main():
    while True:
        print("\n========== ULM DEBATE CENTER ==========")
        print("1. View topics and choose a debate")
        print("2. Add your own debate topic")
        print("3. Choose a random topic")
        print("4. View all topics")
        print("5. Exit")

        choice = input("Choose an option: ").strip()

        if choice == "1":
            view_topics()

        elif choice == "2":
            add_topic()

        elif choice == "3":
            topic = random.choice(topics)
            debate(topic)

        elif choice == "4":
            print("\n========== ALL DEBATE TOPICS ==========")
            for number, topic in enumerate(topics, start=1):
                print(f"{number}. {topic}")

        elif choice == "5":
            print("Thanks for using the ULM Debate Center!")
            break

        else:
            print("Invalid choice. Please enter a number from 1 to 5.")


if __name__ == "__main__":
    main()
